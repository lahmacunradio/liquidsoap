swipebox
===

A touchable jQuery lightbox

---

This is where the build task lives.